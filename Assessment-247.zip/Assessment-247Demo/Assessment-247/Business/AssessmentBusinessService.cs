﻿using Assessment_247.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247.Business
{
    public class AssessmentBusinessService
    {
        public AssessmentModel Reverse(AssessmentModel reverse)
        {
            //placeholders
            string reverseIngredient1 = "";
            string reverseIngredient2 = "";
            //grabs the two ingredients and turns them to a chararray which eventually reverses the words
            for (int i = reverse.Ingredient1.Length - 1; i > -1; i--)
            {
                reverseIngredient1 += reverse.Ingredient1.ToCharArray()[i] + "";
            }
            for (int i = reverse.Ingredient2.Length - 1; i > -1; i--)
            {
                reverseIngredient2 += reverse.Ingredient2.ToCharArray()[i] + "";
            }
            //replaces the ingeridents with the reversed onw
            reverse.Ingredient1 = reverseIngredient1;
           reverse.Ingredient2 = reverseIngredient2;

            //returns the reverse words to the menu
            return reverse;
        }
    }
}
  
