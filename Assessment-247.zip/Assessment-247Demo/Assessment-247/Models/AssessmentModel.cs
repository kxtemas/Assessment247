﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247.Models
{
    public class AssessmentModel
    {
        //THIS IS THE NAME with the displayed title
        [DisplayName("name")]
        public string Name { get; set; }

        //calories with the displayed title
        [DisplayName("Calories")]
        public int Calories { get; set; }

        //ingredident 1 with title
        [DisplayName("ingredient1")]
        public string Ingredient1 { get; set; }

        //ingredient 2 with title
        [DisplayName("ingredient2")]
        public string Ingredient2 { get; set; }

        //constructor 
        public AssessmentModel(string name, int calories, string ingredient1, string ingredient2)
        {
            this.Name = name;
            this.Calories = calories;
            this.Ingredient1 = ingredient1;
           this. Ingredient2 = ingredient2;
        }
        public AssessmentModel()
        {

        }

       
    }
}
