﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assessment_247.Business;
using Assessment_247.Models;

namespace Assessment_247.Controllers
{
    public class AssessmentController : Controller
    {
        public IActionResult Index()
        {
            return View("Menu");
        }
        public IActionResult postMenu(AssessmentModel assessment)
        {
            //instantiate new BusinessService 
            AssessmentBusinessService bs = new AssessmentBusinessService();
            //rewrite the assessment with new ingredients
            assessment = bs.Reverse(assessment);
            //controller returns a assessmentmodel object below the form
            return View("Menu", assessment);
        }
    }
}



